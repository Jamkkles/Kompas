import SwiftUI

enum Brand {
    static let tint: Color = .blue // cámbialo por tu Asset "BrandBlue" si quieres
}
